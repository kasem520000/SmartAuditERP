"""Exclusive R8 postcapture reconciliation, suffix-preserving indexes and guards.
Not run01 input, an extra unittest suite, ERP execution, or semantic exit.
"""
import copy
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import time
import verify_linked_activity as v


def eid(name):return v.identity(name if name.startswith('docs/') else 'docs/audit/evidence/'+name)

def digest(obj):return v.base.sha(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf8'))

def write(name,obj):
    p=v.EV/name
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
    return eid(name)

def common(kind):
    return dict(schema_version=1,kind=kind,assessment_reference_date_utc=v.DATE,session_reference_date_utc=v.SESSION_DATE,
        raw_clocks_are_calendar_authority=False,requested_reference_label_is_claim_about_today=False,
        base_HEAD=v.BASE_HEAD,application_execution_count=0,whole_7B_static_assessment_complete=False,
        capability_exit_certificates_issued=0,four_family_exit_certificates_issued=0,new_accepted_external_handoffs=0,
        phase7C_started=False,phase8_authorized=False,prior196_tests_recertified=False,R2_R3_files_recovered=False)

names=['capability-reconciliation-07B39R8.json','validation-status-supplement-07B39R8.json',
       'index-prefix-supplement-07B39R8.json','publication-check-receipt-07B39R8.json',
       'finalization-before-commit-07B39R8.json']
assert not any((v.EV/n).exists() for n in names)
assert subprocess.run(['git','branch','--show-current'],capture_output=True,text=True,check=True).stdout.strip()=='arena/94ae8414-smartauditerp'
assert subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()==v.BASE_HEAD
assert v.verify(True)['errors']==[]
receipt=v.load('validation-current-run01-receipt-07B39R8.json');by={r['id']:r for r in receipt['records']}
assert len(receipt['inputs_before'])==2381 and receipt['inputs_changed_during_capture']==[]
assert len(by)==15 and receipt['combined_tests_reported']==390 and receipt['combined_tests_all_passed'] is True
assert receipt['combined_actual_partition']==dict(test_recovery_exit=42,test_document_receiver=50,test_production_adjustment=57,test_session_year=62,test_entry_source=86,test_linked_activity=93)
assert receipt['preserved_B38_failure_verbatim']==['AssertionError: 158 != 142'] and receipt['wrapper_exit_code']==1
assert not receipt['all_preserved_and_new_suites_passed']
assert json.loads('['+','.join((v.EV/'validation-current-run01-journal-07B39R8.jsonl').read_text().splitlines())+']')==receipt['records']
archive=receipt['exact_authored_consumed_versions_archive'];assert eid(archive['path'])=={k:archive[k] for k in ('path','bytes','sha256')}
archive_members=[]
with tarfile.open(v.ROOT/archive['path'],'r:gz') as t:
    members=t.getmembers();assert all(m.isfile() for m in members)
    assert [m.name for m in members]==archive['member_paths'] and len(members)==16
    for m in members:
        with t.extractfile(m) as stream:raw=stream.read()
        assert raw==(v.ROOT/m.name).read_bytes()
        assert dict(bytes=len(raw),sha256=v.base.sha(raw))==receipt['inputs_before'][m.name]
        archive_members.append(dict(path=m.name,bytes=len(raw),sha256=v.base.sha(raw)))
for r in receipt['records']:
    for k in ('stdout','stderr'):assert eid(r[k]['path'])==r[k]
    if r['is_test_suite']:
        txt=(v.ROOT/r['stderr']['path']).read_text();match=re.search(r'^Ran (\d+) tests in ([\d.]+)s$',txt,re.M)
        assert (int(match[1]),float(match[2]))==(r['reported_tests'],r['reported_unittest_seconds'])
        cases=re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR)$',txt,re.M)
        assert len(cases)==r['actual_verbose_case_lines']==r['reported_tests']
        assert {s:sum(c[2]==s for c in cases) for s in ('ok','FAIL','ERROR')}==r['actual_case_status_counts']
        assert re.findall(r'^AssertionError:.*$',txt,re.M)==r['assertion_lines_verbatim']
assert sum(r['exit_code']==0 and not r['is_test_suite'] for r in receipt['records'])==7
assert sum(r['exit_code']==2 for r in receipt['records'])==6

old=v.load('capability-reconciliation-07B39R7.json');oldcaps={r['capability_id']:r for r in old['capabilities']}
canonical=v.base.rows('capability-register-07B38.csv');assert len(canonical)==26
review=v.load(v.REVIEW);facts=v.load(v.FACTS);reads=v.load(v.READS);matrix=v.load(v.MATRIX);roots=v.load(v.ROOTS)
capabilities=[]
for row in canonical:
    cid=row['id'];before=oldcaps[cid];assert before['canonical_upstream_row']==row
    new=review['capabilities'].get(cid)
    capabilities.append(dict(capability_id=cid,canonical_upstream_row=row,
        canonical_upstream_row_canonical_json_sha256=digest(row),
        preserved_R7_record_reference=dict(ledger=eid('capability-reconciliation-07B39R7.json'),capability_id=cid,
            canonical_json_sha256=digest(before),record_not_relabelled_as_fresh_R8_review=True),
        new_R8_bounded_review=copy.deepcopy(new),fresh_R8_whole_capability_assessment=False,
        independent_whole_capability_exit=False,whole_capability_certified=False,local_semantic_obligations_complete=False,
        readable_local_externalized=False,
        next_action_source=(new['remaining_readable_local'] if new else before['next_action_source']),
        next_action_precedence='For six R8-touched capabilities use the new per-call decisions/current local worklist; do not ask again for the already read three linked bodies or nineteen LastProcess contexts. Other obligations and old records remain preserved, not completed by this slice.'))
anc=copy.deepcopy(old['preserved_R6_ancestry_object']);assert sum(len(b['records']) for b in anc['bundles'])==37
combined=by['R1-R4-R5-R6-R7-R8-combined-tests'];b38=by['B38-preserved-tests']
validation=dict(receipt=eid('validation-current-run01-receipt-07B39R8.json'),combined_tests=390,combined_passed=390,
    combined_seconds=combined['reported_unittest_seconds'],partition=receipt['combined_actual_partition'],new93_inside390_not_added_again=True,
    B38_tests=43,B38_passed=42,B38_failed=1,B38_seconds=b38['reported_unittest_seconds'],B38_failure_verbatim=b38['assertion_lines_verbatim'],
    all_suites_green=False,seven_integrities_exit0=True,six_completion_gates_exit2_open=True,wrapper_exit_code=1,
    stable_inputs_during_run=2381,consumed_authored_versions_archived=16,preflight_failed_fixture_run_not_relabelled=True)
recon=common('R8-canonical26-reconciliation-with-original-dictionaries-prior-record-pins-and-bounded-source-decisions')
recon.update(canonical_capability_input=eid('capability-register-07B38.csv'),prior_R7_ledger_input=eid('capability-reconciliation-07B39R7.json'),
    canonical_capabilities_count=26,capabilities=capabilities,
    preserved_R7_ancestry_object=anc,preserved_ancestry_input=old['preserved_ancestry_input'],B37_canonical_ancestry_rows=37,
    family_exit_records_are_carried_not_independent_R8_exit_decisions=True,
    families_no_new_exit_decision='Original four-family exit records are carried verbatim in ancestry; all26 capabilities remain incomplete. No family certificate issued by the R8 navigation/linked-item slice.',
    findings=copy.deepcopy(old['findings']),external_boundaries=copy.deepcopy(old['external_boundaries']),
    preserved_prior_R7_findings_delta=copy.deepcopy(old['R7_findings_delta']),preserved_prior_R7_external_delta=copy.deepcopy(old['R7_external_delta']),
    prior_R7_postcapture_followthrough=eid('entry-source-local-followthrough-decisions-07B39R7.json'),
    R8_findings_delta=dict(new_numbered_ids=[],prior339_available_dictionaries_preserved=True,all339_semantically_reread=False,
        historical345_recertified=False,focused_root_reviews=20,source_question_dispositions=14,
        existing_root_support=['P7-059','P7-061','P7-122','P7-129 (individual loader counterexamples retained)',
            'P7-130 (008 customer-labelled action,007 item-only)','P7-132 (potential unchanged)','P7-160','P7-161','P1-012'],
        unnumbered_source_questions=[r['id'] for r in roots['candidate_dispositions'] if r['root_id'] is None],
        purchase_guard_not_forced_into_P7_159=True,contract_target_not_forced_into_P7_144=True,root_remediated=False),
    R8_external_delta=dict(new_formal_boundary_rows=0,new_accepted_handoffs=0,readable_local_moved_to_absent_SDK=False,
        individual_unavailable_contract_notes=3,owned_unprovided_notes=eid(v.REVIEW)),
    actual_validation=validation,
    new_source_work=dict(selected_whole_method_or_constructor_contexts=209,source_identities=32,
        self_reported_display_ranges=217,original_LastProcess_calls=19,original_linked_insert_calls=11,
        original_pending_linked_bodies_now_read=3,individual_call_decisions=30,source_decisions=11,
        reopen_Navigate_sites=14,reopen_case_labels=16,reopen_receiver_types=7,
        full_all_receiver_helper_or_Save_or_allowed_set_completion=False,repository_alias_or_compiler_binding_claim=False),
    source_review_input=eid('docs/audit/SOURCE-REVIEW-07B39R8.md'),bounded_review_input=eid(v.REVIEW),
    request_matrix_input=eid(v.MATRIX),local_successor_worklist_input=eid(v.WORK),reference_date_note=eid(v.DATE_NOTE),
    ledger_validation_phase_and_index_prefixes_were_run01_inputs=False)
write(names[0],recon)
status=common('R8-postcapture-validation-status-supplement-not-input-to390-or-new-test-suite')
status.update(actual_validation=validation,receipt=eid('validation-current-run01-receipt-07B39R8.json'),
    journal=eid('validation-current-run01-journal-07B39R8.jsonl'),archive=eid(archive['path']),
    consumed_authored_member_identities=archive_members,actual_stream_pairs=15,
    source_assertions_are_not_independent_reading_or_calendar_or_runtime_or_financial_acceptance=True,
    own_preflight_failure=eid('preflight-authorship-receipt-07B39R8.json'),
    prior_R5_run01_failure_preserved=True,prior_R7_run01_receipt=eid('validation-current-run01-receipt-07B39R7.json'),
    new_postcapture_unittest_cases=0,whole_7B_exit_issued=False)
write(names[1],status)

prefixes={
'README.md':'''# الحالة الحالية — 07B39R8: آخر حركة والإدراج المرتبط بأحكام فردية

**7B مفتوحة؛ صفر شهادة قدرة/أسرة وصفر إحالة إكمال جديدة مقبولة.** أُنجزت الأجسام الثلاثة المتبقية للإدراج وتقييم هويات LastProcess19 وlinked11 كلٌّ بمصدر وسائطه ونطاقه وإلغائه/نشره. لا يوقف رفض void btnNew المتصل الخارجي، وref-binding يسبق قبول البنود، وكاتب العقد المختار يستعمل inv لا invcontract. لا تعميم لخلل نوع الطرف: المشتريات الحديثة والعقد الافتراضي شاهدان مضادان. دعم جذور قائمة وأسئلة غير مرقمة، لا معالجة أو خروج من العدّ.

**run01:390/390 في49.866ثانية** =42+50+57+62+86+93، والجديدة93 ضمن390. **B38:42نجاحًا وفشل1/43 (`158 != 142`)**؛ سبعة فحوص سلامة0 وست بوابات إكمال2/open والغلاف1. فشل R5run01 وفشل تهيئة R8 الأول محفوظان؛ ليست جميع المجموعات خضراء.

[التسليم الحالي](PHASE-07B39R8.md) · [المصدر المستهلك](SOURCE-REVIEW-07B39R8.md) · [مصفوفة30](evidence/linked-activity-call-matrix-07B39R8.json) · [التحقق](VALIDATION-07B39R8.md) · [سجل القدرات26](evidence/capability-reconciliation-07B39R8.json) · [المتبقي المحلي](evidence/linked-activity-local-worklist-07B39R8.json) · [توضيح المرجع](evidence/reference-date-provenance-07B39R8.json)

827مصدر تطبيق دون تغيير أو تشغيل؛339قاموسًا متاحًا لا إعادة تصديق345/196/49الغائبة. التالي Save/allowed-edit ومجموعات المستندات المسموحة وبقية الكتّاب/المتصلين/السنة. المرجع المطلوب21نوفمبر2026 استشرافي وليس تاريخ اليوم أو توثيق قراءة؛ تاريخ الجلسة16نوفمبر منفصل والأصول مجمدة. 7Cلمتبدأ و8غيرمأذونة. النص التالي محفوظ ببايتاته كتسليم R7 وما قبله لا الحالة الحالية.

## أرشيف R7 وما قبله — النص التالي محفوظ كاملًا

''',
'PLAN.md':'''# خطة المتابعة — 07B39R8 ضمن القدرات26 المعتمدة

أُنجزت الأجسام الثلاثة المحددة للإدراج وهويات LastProcess19/linked11 مع عقود المصدر/الاختيار/المرشحات والإلغاء والنشر وأصل الاتصال. لا تُطلب الأجسام المنجزة مجددًا لمجرد زيادة عدّ؛ رايات R6 الأصلية محفوظة إلى جانب تقييم R8 لا معاد كتابتها. التقدم جزئي في D08/D17/D19/D21/D22/D25، لا خروج لأي قدرة أو أسرة.

**التالي:** Save/allowed-edit ومجموعات المستندات المسموحة في المحررات المختارة، ثم بقية كتّاب السطر/copy/merge وكمية/وحدة/سعر/خصم/VAT، وبقية متصلي المنتقي المباشرين وCond/Return والهوية والنتيجة وملاك السنة/الإغلاق. يبقى @Recipient وسائر أسئلة R7/R5/R6 المحمولة مفتوحة. لا يُحال المصدر المحلي إلى عقد DTO/SDK غير متاح، ولا قبول إحالة إكمال قبل استيفائه.

[قائمة العمل الحالية](evidence/linked-activity-local-worklist-07B39R8.json) · [مصفوفة النداءات30](evidence/linked-activity-call-matrix-07B39R8.json) · [التسليم](PHASE-07B39R8.md) · [المصدر](SOURCE-REVIEW-07B39R8.md) · [سجل26](evidence/capability-reconciliation-07B39R8.json) · [التحقق](VALIDATION-07B39R8.md)

390/390 ناجحة، لكن B38فاشلة `158 != 142` وست بوابات2/open. لا تعديل تطبيق أو اختبار تاريخي/توقع142 ولا قبول مالي/تشغيلي أو خروج7B/بدء7C/تفويض8. المرجع المطلوب21نوفمبر استشرافي مع بقاء تاريخ الجلسة16نوفمبر منفصلًا؛ لا توثيق تقويم أو عرض رجعي. النص التالي محفوظ حرفيًا كتسليم R7 وما قبله.

## أرشيف R7 وما قبله — النص التالي محفوظ كاملًا

''',
'IMPROVEMENTS.md':'''# متابعة 07B39R8 — قرارات مصدر لا إصلاح أو إغلاق

ثُبتت فروق المتصلين19 لا حكم mismatch شامل: المشتريات الحديثة2 والعقد23→1 يطابقان loader، وبعض المسارات القديمة/POS/IO لا يحافظ على نوع الطرف. XAML يثبت أن008 هو أمر العميل القديم الذي يرسل-1. all-stores وTOP1 ASC وإعادة الفتح برقم محلي/اسم عرض تدعم P7-122/059/061/129/130 القائمة؛ P7-132 تبقىpotential ولا تُحسم بترتيب Show.

في الإدراج11، ref-binding يسبق قبول البنود، والأب يتابع بعد void بلا accepted result؛ دعم P7-160/161. رفض btnNew غير المنقول يبقى سؤالًا غير مرقم لا دمجًا قسريًا مع159؛ invcontract مقابل inv وItemId-only ليسا تلقائيًا جذر آخر صف144. لا defaults/alias/SQL/فشل مالي أو قبول تشغيل مفترض، ولا أرقام جديدة مع الست المفقودة.

[المصدر](SOURCE-REVIEW-07B39R8.md) · [أحكام المصدر](evidence/linked-activity-dispositions-07B39R8.json) · [الجذور](evidence/linked-activity-root-adjudication-07B39R8.json) · [التحقق](VALIDATION-07B39R8.md) · [التسليم](PHASE-07B39R8.md):390/390ناجحًا، لكن B38فشل1/43 (`158 != 142`)، وست بوابات إكمال2/open والغلاف1. فشلا تهيئة R8 الأول وفشلR5run01 محفوظان لا مخفيان.

827مصدر تطبيق وسجل335/raw336CRLF وملحقR1 محفوظة؛339متاحة لا تصديق345/196/49. لا معالجة أو قبول مالي/تشغيلي؛7Bمفتوحة،7Cلمتبدأ و8غيرمأذونة. المرجع المطلوب21نوفمبر استشرافي لا تاريخ اليوم؛ تاريخ الجلسة16نوفمبر منفصل والأصول محفوظة. النص التالي كامل ببايتاته كتسليم R7 وما قبله.

## أرشيف R7 وما قبله — النص التالي محفوظ كاملًا

'''}
index_records=[]
entry=v.load(v.ENTRY)
for name,prefix in prefixes.items():
    rel='docs/audit/'+name;p=v.ROOT/rel;raw=p.read_bytes();expected=entry['preserved_tracked_audit_inputs'][rel]
    assert dict(bytes=len(raw),sha256=v.base.sha(raw))==expected
    start=prefix.encode('utf8');p.write_bytes(start+raw)
    index_records.append(dict(path=rel,prefix_utf8_text=prefix,prefix_bytes=len(start),prefix_sha256=v.base.sha(start),
        preserved_old_suffix=expected,after=eid(rel),original_suffix_preserved_verbatim=True,
        prefix_was_run01_input=False,prior_text_is_archive_not_current_status=True))
indexnote=common('R8-new-current-index-prefixes-with-verbatim-prior-suffixes-not-run01-input')
indexnote.update(indexes=index_records,prior_current_sections_not_deleted_or_relabelled_as_R8=True,
    canonical_capability_ledger=eid(names[0]),validation_status_supplement=eid(names[1]),
    current_phase=eid('docs/audit/PHASE-07B39R8.md'),current_validation=eid('docs/audit/VALIDATION-07B39R8.md'),
    current_source_review=eid('docs/audit/SOURCE-REVIEW-07B39R8.md'),reference_date_note=eid(v.DATE_NOTE))
write(names[2],indexnote)

# Three real later guards, not a retroactive390 test result. Preserve own streams.
commands=[('R8-integrity',[sys.executable,'-B','-W','error::ResourceWarning','docs/audit/tools/disposition07b/verify_linked_activity.py','--verify','--rederive'],0),
          ('R8-open-gate',[sys.executable,'-B','-W','error::ResourceWarning','docs/audit/tools/disposition07b/verify_linked_activity.py','--verify','--require-complete','--rederive'],2),
          ('B38-integrity',[sys.executable,'-B','-W','error::ResourceWarning','docs/audit/tools/census07b/validate_7b_completion.py','--reparse'],0)]
records=[]
for label,argv,expected in commands:
    out=v.EV/f'publication-check-{label}-07B39R8.stdout.txt';err=v.EV/f'publication-check-{label}-07B39R8.stderr.txt'
    assert not out.exists() and not err.exists();tick=time.monotonic()
    with out.open('xb') as stdout,err.open('xb') as stderr:proc=subprocess.run(argv,cwd=v.ROOT,stdout=stdout,stderr=stderr,check=False)
    parsed=json.loads(out.read_bytes())
    records.append(dict(id=label,argv=argv,cwd='.',exit_code=proc.returncode,expected_exit=expected,
        expected_exit_matched=proc.returncode==expected,wall_seconds=round(time.monotonic()-tick,6),
        stdout=eid(out.relative_to(v.ROOT).as_posix()),stderr=eid(err.relative_to(v.ROOT).as_posix()),parsed_stdout=parsed,
        is_unittest_suite=False,new_ERP_or_SQL_execution=False))
    assert proc.returncode==expected and parsed.get('errors',parsed.get('integrity_errors'))==[],records[-1]
checks=common('actual-postpublication-R8-guards-not-unittest-or-run01-recapture')
checks.update(records=records,new_unittest_cases=0,run01_rewritten=False,all_expected_guard_exits_matched=True)
write(names[3],checks)

# Finalization independently rechecks the entire captured input snapshot, all
# versioned packet pins, indexes, canonical dictionaries and new local links.
errors=[]
def need(ok,label):
    if not ok:errors.append(label)
need(v.verify(True)['errors']==[],'R8-current-source-evidence-rederivation')
need(v.preservation_errors(entry)==[],'all1538-prior-audit-and827-application')
need(v.load(names[0])['preserved_R7_ancestry_object']==old['preserved_R6_ancestry_object'],'all37-ancestry-and-four-family-records')
for row in v.load(names[0])['capabilities']:
    cid=row['capability_id'];need(row['canonical_upstream_row']==next(r for r in canonical if r['id']==cid),'canonical26:'+cid)
    need(row['preserved_R7_record_reference']['canonical_json_sha256']==digest(oldcaps[cid]),'prior-R7-record:'+cid)
    need(row['new_R8_bounded_review']==review['capabilities'].get(cid),'new-qualified-six:'+cid)
    need(row['whole_capability_certified'] is False and row['independent_whole_capability_exit'] is False,'no-capability-exit:'+cid)
changed=[]
for rel,expected in receipt['inputs_before'].items():
    actual=eid(rel);raw=(v.ROOT/rel).read_bytes()
    if {k:actual[k] for k in ('bytes','sha256')}!=expected:
        changed.append(rel)
        need(rel in {'docs/audit/'+n for n in prefixes},'unexpected-captured-input-diff:'+rel)
        need(len(raw)>expected['bytes'] and v.base.sha(raw[-expected['bytes']:])==expected['sha256'],'non-prefix-captured-input-diff:'+rel)
need(sorted(changed)==sorted('docs/audit/'+n for n in prefixes),'only-three-current-index-differences')
for rec in index_records:
    raw=(v.ROOT/rec['path']).read_bytes();n=rec['prefix_bytes'];need(raw[:n].decode('utf8')==rec['prefix_utf8_text'],'prefix-text:'+rec['path'])
    need(v.base.sha(raw[n:])==rec['preserved_old_suffix']['sha256'],'verbatim-old-index-suffix:'+rec['path'])
for member in archive_members:need(eid(member['path'])==member,'exact-authored-consumed-member:'+member['path'])
for name in (v.DATE_NOTE,v.READS,v.ROOTS,v.MATRIX,v.WORK,v.REVIEW):
    for pin in v.load(name).get('pinned_inputs',[]):need(eid(pin['path'])==pin,'explicit-version-pin:'+pin['path'])
new_links=[]
texts=[('docs/audit/'+n,(v.AUDIT/n).read_text()) for n in ('PHASE-07B39R8.md','VALIDATION-07B39R8.md','SOURCE-REVIEW-07B39R8.md')]
texts += [('docs/audit/'+n,s) for n,s in prefixes.items()]
for origin,text in texts:
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
        if target.startswith(('https:','http:','#','mailto:')):continue
        p=(v.ROOT/origin).parent/target.split('#',1)[0];need(p.is_file(),'new-local-link:'+origin+'->'+target)
        if p.is_file():new_links.append(dict(origin=origin,target=target,resolved_identity=eid(p.relative_to(v.ROOT).as_posix())))
# Audit-only worktree, original application bytes and all historical tools pinned
# by entry, no move/rename/delete outside the three prefix-only documents.
statuslines=subprocess.run(['git','status','--porcelain','-uall'],cwd=v.ROOT,capture_output=True,text=True,check=True).stdout.splitlines()
for line in statuslines:need(line[3:].startswith('docs/audit/'),'non-audit-worktree-change:'+line)
need(not errors,'all-finalization-claims-checked')
packet_paths={p.relative_to(v.ROOT).as_posix() for p in v.AUDIT.rglob('*') if p.is_file() and v.TAG in p.name}
packet_paths|={'docs/audit/tools/disposition07b/'+n for n in ('verify_linked_activity.py','test_linked_activity.py','capture_linked_activity.py')}
packet_paths|={'docs/audit/'+n for n in prefixes};packet_paths.discard('docs/audit/evidence/'+names[4])
final=common('R8-finalization-after-publication-before-commit-not-phase-exit-calendar-or-financial-certificate')
final.update(errors=errors,post_publication_checks_receipt=eid(names[3]),application_sources=827,
    application_source_bytes=sum(int(r['bytes']) for r in v.base.rows('inventory.csv')),application_sources_unchanged=True,
    prior_tracked_audit_inputs_preserved=1538,run01_input_identities=2381,run01_inputs_changed_during_capture=[],
    run01_input_differences_after_publication=sorted(changed),only_suffix_preserving_index_prefixes_allowed=True,
    actual_validation=validation,actual_stream_pairs_preserved=15,authored_consumed_versions_archived=16,
    authored_archive_identity=eid(archive['path']),authored_member_identities=archive_members,
    preserved_preflight_failure=eid('preflight-authorship-receipt-07B39R8.json'),
    canonical26_original_rows_preserved=True,prior_R7_record_pointers_checked=26,canonical_B37_ancestry_rows_preserved=37,
    focused_existing_root_comparisons=20,all339_semantically_reread_in_R8=False,all345_novelty_certified=False,
    new_accepted_unavailable_handoffs=0,new_local_links=new_links,pinned_packet_files=[eid(p) for p in sorted(packet_paths)],
    new_postcapture_unittest_cases=0,source_or_capture_versions_rewritten=False,
    no_same_packet_self_pin=True,future_commit_id_invented=False)
write(names[4],final)
assert errors==[],errors
print(json.dumps(dict(errors=errors,original_canonical_capabilities=26,ancestry37_preserved=True,
    postpublication_guard_exits=[r['exit_code'] for r in records],input_differences=sorted(changed),
    pinned_packet_files=len(final['pinned_packet_files']),new_local_links=len(new_links),
    combined_cases=390,combined_seconds=49.866,B38_assertion='158 != 142',all_suites_green=False,
    whole_7B_static_assessment_complete=False),ensure_ascii=False,indent=2))
