"""Resume finalization only. Never rerun the exclusive author/capture/prefix steps."""
import json
from pathlib import Path
import re
import subprocess
import tarfile
import verify_linked_activity as v


def eid(name):
    # Application paths are repository-relative too, not evidence basenames.
    return v.identity(name if name.startswith(('docs/', 'SmartAuditERP')) else 'docs/audit/evidence/'+name)


def digest(obj):return v.base.sha(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf8'))

errors=[]
def need(ok,label):
    if not ok:errors.append(label)

name='finalization-before-commit-07B39R8.json'
assert not (v.EV/name).exists()
entry=v.load(v.ENTRY);receipt=v.load('validation-current-run01-receipt-07B39R8.json')
recon=v.load('capability-reconciliation-07B39R8.json');old=v.load('capability-reconciliation-07B39R7.json')
oldcaps={r['capability_id']:r for r in old['capabilities']};canonical=v.base.rows('capability-register-07B38.csv')
review=v.load(v.REVIEW);status=v.load('validation-status-supplement-07B39R8.json')
indexnote=v.load('index-prefix-supplement-07B39R8.json');index_records=indexnote['indexes']
indexes={r['path'] for r in index_records};archive=receipt['exact_authored_consumed_versions_archive']
checks=v.load('publication-check-receipt-07B39R8.json')
need(subprocess.run(['git','branch','--show-current'],capture_output=True,text=True,check=True).stdout.strip()=='arena/94ae8414-smartauditerp','correct-session-branch')
need(subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()==v.BASE_HEAD,'correct-base-before-commit')
current=v.verify(True);need(current['errors']==[],'R8-current-source-evidence-rederivation')
prior_check=v.previous.verify(True);need(prior_check['errors']==[],'R7-preserved-current-rederivation')
need(v.preservation_errors(entry)==[],'all1538-prior-audit-and827-application')
need(recon['preserved_R7_ancestry_object']==old['preserved_R6_ancestry_object'],'all37-ancestry-and-four-family-records')
need(sum(len(b['records']) for b in recon['preserved_R7_ancestry_object']['bundles'])==37,'actual37-ancestry-records')
need(len(canonical)==len(recon['capabilities'])==26,'actual26-canonical-rows')
for row in recon['capabilities']:
    cid=row['capability_id'];need(row['canonical_upstream_row']==next(r for r in canonical if r['id']==cid),'canonical26:'+cid)
    need(row['canonical_upstream_row_canonical_json_sha256']==digest(row['canonical_upstream_row']),'canonical26-digest:'+cid)
    need(row['preserved_R7_record_reference']['canonical_json_sha256']==digest(oldcaps[cid]),'prior-R7-record:'+cid)
    need(row['new_R8_bounded_review']==review['capabilities'].get(cid),'new-qualified-six:'+cid)
    need(row['whole_capability_certified'] is False and row['independent_whole_capability_exit'] is False,'no-capability-exit:'+cid)
    need(eid(row['preserved_R7_record_reference']['ledger']['path'])==row['preserved_R7_record_reference']['ledger'],'prior-ledger-pin:'+cid)
changed=[]
need(len(receipt['inputs_before'])==2381 and receipt['inputs_changed_during_capture']==[],'actual2381-stable-during-run01')
for rel,expected in receipt['inputs_before'].items():
    actual=eid(rel);raw=(v.ROOT/rel).read_bytes()
    if {k:actual[k] for k in ('bytes','sha256')}!=expected:
        changed.append(rel);need(rel in indexes,'unexpected-captured-input-diff:'+rel)
        need(len(raw)>expected['bytes'] and v.base.sha(raw[-expected['bytes']:])==expected['sha256'],'non-prefix-captured-input-diff:'+rel)
need(sorted(changed)==sorted(indexes),'only-three-current-index-differences')
for rec in index_records:
    raw=(v.ROOT/rec['path']).read_bytes();n=rec['prefix_bytes']
    need(raw[:n].decode('utf8')==rec['prefix_utf8_text'],'prefix-text:'+rec['path'])
    need(v.base.sha(raw[:n])==rec['prefix_sha256'],'prefix-hash:'+rec['path'])
    need(v.base.sha(raw[n:])==rec['preserved_old_suffix']['sha256'],'verbatim-old-index-suffix:'+rec['path'])
    need(eid(rec['path'])==rec['after'],'post-index-identity:'+rec['path'])
need(eid(archive['path'])=={k:archive[k] for k in ('path','bytes','sha256')},'archive-identity')
archive_members=[]
with tarfile.open(v.ROOT/archive['path'],'r:gz') as t:
    members=t.getmembers();need(len(members)==16 and [m.name for m in members]==archive['member_paths'],'archive16-member-names')
    for m in members:
        need(m.isfile(),'only-file-archive-member:'+m.name)
        with t.extractfile(m) as stream:raw=stream.read()
        need(raw==(v.ROOT/m.name).read_bytes(),'exact-authored-consumed-member:'+m.name)
        pin=dict(path=m.name,bytes=len(raw),sha256=v.base.sha(raw));archive_members.append(pin)
        need({k:pin[k] for k in ('bytes','sha256')}==receipt['inputs_before'][m.name],'archive-matches-captured-before:'+m.name)
need(archive_members==status['consumed_authored_member_identities'],'status-member-list-exact')
need(status['actual_validation']==recon['actual_validation'],'status-vs-ledger-validation')
journal=[json.loads(line) for line in (v.EV/'validation-current-run01-journal-07B39R8.jsonl').read_text().splitlines()]
need(journal==receipt['records'] and len(journal)==15,'fifteen-real-journal-rows')
for row in receipt['records']+checks['records']:
    for key in ('stdout','stderr'):need(eid(row[key]['path'])==row[key],'stream-pin:'+row[key]['path'])
    if row.get('is_test_suite'):
        text=(v.ROOT/row['stderr']['path']).read_text();m=re.search(r'^Ran (\d+) tests in ([\d.]+)s$',text,re.M)
        need(m is not None and (int(m[1]),float(m[2]))==(row['reported_tests'],row['reported_unittest_seconds']),'actual-suite-summary:'+row['id'])
        cases=re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. (ok|FAIL|ERROR)$',text,re.M)
        need(len(cases)==row['actual_verbose_case_lines']==row['reported_tests'],'actual-verbose-cases:'+row['id'])
        need({s:sum(c[2]==s for c in cases) for s in ('ok','FAIL','ERROR')}==row['actual_case_status_counts'],'actual-case-statuses:'+row['id'])
        need(re.findall(r'^AssertionError:.*$',text,re.M)==row['assertion_lines_verbatim'],'actual-assertion-lines:'+row['id'])
need([r['exit_code'] for r in checks['records']]==[0,2,0],'actual-later-guards0-2-0-not-unittest')
need(receipt['wrapper_exit_code']==1 and not receipt['all_preserved_and_new_suites_passed'],'preserved-real-B38-failure-wrapper1')
need(len(list((v.AUDIT/'tools').rglob('*.py')))==158,'unchanged-active-tool-count158-not142')
for n in (v.DATE_NOTE,v.READS,v.ROOTS,v.MATRIX,v.WORK,v.REVIEW):
    for pin in v.load(n).get('pinned_inputs',[]):need(eid(pin['path'])==pin,'explicit-version-pin:'+pin['path'])
for n,keys in [('index-prefix-supplement-07B39R8.json',('canonical_capability_ledger','validation_status_supplement','current_phase','current_validation','current_source_review','reference_date_note'))]:
    obj=v.load(n)
    for key in keys:need(eid(obj[key]['path'])==obj[key],'postcapture-pin:'+key)
resume=v.load('publication-finalization-authorship-note-07B39R8.json')
for pin in resume['already_written_and_not_to_rerun']:need(eid(pin['path'])==pin,'no-rerun-publication-version:'+pin['path'])
new_links=[]
texts=[('docs/audit/'+n,(v.AUDIT/n).read_text()) for n in ('PHASE-07B39R8.md','VALIDATION-07B39R8.md','SOURCE-REVIEW-07B39R8.md')]
texts += [(r['path'],r['prefix_utf8_text']) for r in index_records]
for origin,text in texts:
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
        if target.startswith(('https:','http:','#','mailto:')):continue
        p=(v.ROOT/origin).parent/target.split('#',1)[0]
        need(p.is_file(),'new-local-link:'+origin+'->'+target)
        if p.is_file():new_links.append(dict(origin=origin,target=target,resolved_identity=eid(p.relative_to(v.ROOT).as_posix())))
statuslines=subprocess.run(['git','status','--porcelain','-uall'],cwd=v.ROOT,capture_output=True,text=True,check=True).stdout.splitlines()
for line in statuslines:need(line[3:].startswith('docs/audit/'),'non-audit-worktree-change:'+line)
assert not errors,errors
packet_paths={p.relative_to(v.ROOT).as_posix() for p in v.AUDIT.rglob('*') if p.is_file() and v.TAG in p.name}
packet_paths|={'docs/audit/tools/disposition07b/'+n for n in ('verify_linked_activity.py','test_linked_activity.py','capture_linked_activity.py')}
packet_paths|=indexes;packet_paths.discard('docs/audit/evidence/'+name)
final=dict(schema_version=1,kind='R8-resumed-finalization-after-publication-before-commit-not-phase-calendar-or-financial-certificate',
    assessment_reference_date_utc=v.DATE,session_reference_date_utc=v.SESSION_DATE,requested_reference_label_is_claim_about_today=False,
    raw_clocks_are_calendar_authority=False,base_HEAD=v.BASE_HEAD,branch='arena/94ae8414-smartauditerp',errors=errors,
    post_publication_checks_receipt=eid('publication-check-receipt-07B39R8.json'),
    resumed_after_preserved_path_resolution_error=eid('publication-finalization-authorship-note-07B39R8.json'),
    source_author_capture_or_prefixes_rerun=False,R8_rederived_errors=current['errors'],R7_rederived_errors=prior_check['errors'],
    application_sources=827,application_source_bytes=sum(int(r['bytes']) for r in v.base.rows('inventory.csv')),application_sources_unchanged=True,
    prior_tracked_audit_inputs_preserved=1538,run01_input_identities=2381,run01_inputs_changed_during_capture=[],
    run01_input_differences_after_publication=sorted(changed),only_suffix_preserving_index_prefixes_allowed=True,
    actual_validation=recon['actual_validation'],actual_stream_pairs_preserved=15,authored_consumed_versions_archived=16,
    authored_archive_identity=eid(archive['path']),authored_member_identities=archive_members,
    preserved_preflight_failure=eid('preflight-authorship-receipt-07B39R8.json'),
    canonical26_original_rows_preserved=True,prior_R7_record_pointers_checked=26,canonical_B37_ancestry_rows_preserved=37,
    focused_existing_root_comparisons=20,all339_semantically_reread_in_R8=False,all345_novelty_certified=False,
    new_local_links=new_links,pinned_packet_files=[eid(p) for p in sorted(packet_paths)],
    new_postcapture_unittest_cases=0,source_or_capture_versions_rewritten=False,no_same_packet_self_pin=True,future_commit_id_invented=False,
    application_execution_count=0,whole_7B_static_assessment_complete=False,capability_exit_certificates_issued=0,
    four_family_exit_certificates_issued=0,new_accepted_external_handoffs=0,phase7C_started=False,phase8_authorized=False,
    prior196_tests_recertified=False,R2_R3_files_recovered=False)
with (v.EV/name).open('x',encoding='utf8',newline='\n') as f:json.dump(final,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(dict(errors=errors,original_canonical_capabilities=26,ancestry37_preserved=True,
    postpublication_guard_exits=[r['exit_code'] for r in checks['records']],input_differences=sorted(changed),
    pinned_packet_files=len(final['pinned_packet_files']),new_local_links=len(new_links),combined_cases=390,combined_seconds=49.866,
    B38_assertion='158 != 142',all_suites_green=False,whole_7B_static_assessment_complete=False,
    resumed_finalization_only=True),ensure_ascii=False,indent=2))
